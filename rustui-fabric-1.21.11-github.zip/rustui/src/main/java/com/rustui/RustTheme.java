package com.rustui;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Util;

public final class RustTheme {
    public static final int BG        = 0xFF1A1A1A;
    public static final int PANEL     = 0xF0141414;
    public static final int PANEL_EDGE= 0xFF2A2A2A;
    public static final int BTN       = 0xFF2B2B2B;
    public static final int RED       = 0xFFCD412B;
    public static final int TEXT      = 0xFFD9D9D9;
    public static final int TEXT_DIM  = 0xFF8A8A8A;
    public static final int WHITE     = 0xFFFFFFFF;
    public static final int BAR_BG    = 0xFF0E0E0E;
    public static final int PANEL_W   = 260;

    private RustTheme() {}

    public static void drawBackground(GuiGraphics g, int w, int h) {
        g.fill(0, 0, w, h, BG);
        // subtle vignette strips
        g.fill(0, 0, w, 40, 0x30000000);
        g.fill(0, h - 40, w, h, 0x30000000);
    }

    public static void drawLeftPanel(GuiGraphics g, int h) {
        g.fill(0, 0, PANEL_W, h, PANEL);
        g.fill(PANEL_W, 0, PANEL_W + 2, h, RED);
    }

    public static void drawCentered(GuiGraphics g, Font font, Component c, int cx, int y, int color) {
        g.drawString(font, c, cx - font.width(c) / 2, y, color);
    }

    /** Bottom loading strip. progress < 0 = indeterminate animation. */
    public static void drawLoadingBar(GuiGraphics g, int w, int h, float progress) {
        int barH = 6;
        int y = h - barH;
        g.fill(0, y, w, h, BAR_BG);
        if (progress >= 0f) {
            int fw = (int) (w * Math.min(1f, progress));
            g.fill(0, y, fw, h, RED);
        } else {
            int seg = w / 4;
            double t = (Util.getMillis() % 1600L) / 1600.0;
            int x = (int) (-seg + t * (w + seg));
            g.fill(Math.max(0, x), y, Math.min(w, x + seg), h, RED);
        }
    }

    public static void drawStatus(GuiGraphics g, Font font, int w, int h, Component title, Component sub) {
        drawBackground(g, w, h);
        drawLeftPanel(g, h);
        g.drawString(font, Component.literal("RUST").withStyle(s -> s.withBold(true)), 24, 24, RED);
        g.drawString(font, title, 24, h - 52, WHITE);
        if (sub != null) g.drawString(font, sub, 24, h - 38, TEXT_DIM);
    }
}
