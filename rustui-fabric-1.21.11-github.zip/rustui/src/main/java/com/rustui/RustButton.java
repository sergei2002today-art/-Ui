package com.rustui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

public class RustButton extends Button {
    public RustButton(int x, int y, int w, int h, Component label, OnPress onPress) {
        super(x, y, w, h, label, onPress, DEFAULT_NARRATION);
    }

    @Override
    public void renderContents(GuiGraphics g, int mouseX, int mouseY, float delta) {
        boolean hot = this.isHoveredOrFocused();
        int x = getX(), y = getY(), w = getWidth(), h = getHeight();
        // fully cover whatever the vanilla button drew underneath
        g.fill(x, y, x + w, y + h, hot ? RustTheme.RED : RustTheme.BTN);
        if (!hot) g.fill(x, y, x + 2, y + h, RustTheme.PANEL_EDGE);
        var font = Minecraft.getInstance().font;
        g.drawString(font, getMessage(), x + 12, y + (h - 8) / 2, hot ? RustTheme.WHITE : RustTheme.TEXT);
    }
}
