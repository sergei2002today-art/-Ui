package com.rustui;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.network.chat.Component;

public class RustTitleScreen extends Screen {
    public RustTitleScreen() {
        super(Component.translatable("narrator.screen.title"));
    }

    @Override
    protected void init() {
        int x = 24, w = RustTheme.PANEL_W - 48, h = 26, gap = 6;
        int y = this.height / 2 - 40;
        addRenderableWidget(new RustButton(x, y, w, h, Component.translatable("menu.singleplayer"),
                b -> minecraft.setScreen(new SelectWorldScreen(this))));
        y += h + gap;
        addRenderableWidget(new RustButton(x, y, w, h, Component.translatable("menu.multiplayer"),
                b -> minecraft.setScreen(new JoinMultiplayerScreen(this))));
        y += h + gap;
        addRenderableWidget(new RustButton(x, y, w, h, Component.translatable("menu.options"),
                b -> minecraft.setScreen(new OptionsScreen(this, minecraft.options))));
        y += h + gap;
        addRenderableWidget(new RustButton(x, y, w, h, Component.translatable("menu.quit"),
                b -> minecraft.stop()));
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float delta) {
        RustTheme.drawBackground(g, width, height);
        RustTheme.drawLeftPanel(g, height);
        g.drawString(font, Component.literal("RUST").withStyle(s -> s.withBold(true)), 24, 24, RustTheme.RED);
        g.drawString(font, Component.literal("Minecraft " + net.minecraft.SharedConstants.getCurrentVersion().name()),
                24, height - 20, RustTheme.TEXT_DIM);
    }

    @Override
    public boolean shouldCloseOnEsc() { return false; }
}
